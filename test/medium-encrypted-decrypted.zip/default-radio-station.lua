---------------------------------------------
--- file:		default-radio-station.lua ---
--- version:	1.1						  ---
--- author:		sakratt					  ---
---------------------------------------------

--- SETTINGS ---
drs_radio_station_lock = false -- Whether to forcefully only stay on one station
drs_radio_station_index = 1
-- 0. No Radio -- NOTE: Unfortunately, does not work yet
-- 1. Los Santos Rock Radio
-- 2. Non Stop Pop FM
-- 3. Radio Los Santos
-- 4. Channel X
-- 5. West Coast Talk Radio
-- 6. Rebel Radio
-- 7. Soulwax FM
-- 8. East Los FM
-- 9. West Coast Classics
-- 10. The Blue Ark
-- 11. World Wide FM
-- 12. FlyLo FM
-- 13. The Lowdown
-- 14. The Lab
-- 15. Radio Mirror Park
-- 16. Space
-- 17. Vinewood Boulevard Radio
-- 18. Self Radio









--- DEFAULT RADIO STATIONS ---
local defaultRadioStation = {}

local changedInCurrent = false
local index = drs_radio_station_index
if index == 0 then
	-- If anyone has a fix, please let me know.
else
	index = index - 1
end

function defaultRadioStation.tick()
	local playerPed = PLAYER.PLAYER_PED_ID()
	local player = PLAYER.GET_PLAYER_PED(playerPed)
	if not ENTITY.DOES_ENTITY_EXIST(playerPed) then return end
	
	if PED.IS_PED_IN_ANY_VEHICLE(playerPed, false) then
		if not changedInCurrent and AUDIO.GET_PLAYER_RADIO_STATION_INDEX() ~= index then
			AUDIO.SET_RADIO_TO_STATION_INDEX(index)
			changedInCurrent = true
		end
	else
		changedInCurrent = false
	end
end

return defaultRadioStation